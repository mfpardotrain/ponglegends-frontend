
class OnRightClick {

    constructor() {
        
    }

    mousePosition() {

    }

    onClick() {

    }
}

export default onRightClick;
